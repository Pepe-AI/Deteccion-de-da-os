# main.py
from fastapi import FastAPI, Request, HTTPException
from services.image_procesing import process_whatsapp_image

app = FastAPI()

@app.post("/receive-whatsapp-message/")
async def receive_whatsapp_message(request: Request):
    try:
        form_data = await request.form()
        result = await process_whatsapp_image(form_data)
        return result

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

