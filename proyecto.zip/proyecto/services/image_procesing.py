# services/image_processing.py
import requests
from fastapi import HTTPException
from twilio_client import twilio_client
from config import TWILIO_WHATSAPP_NUMBER, TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN
from services.car_deteccion import detect_car_in_image
from services.damage_analysis import analyze_car_damage

async def process_whatsapp_image(form_data):
    media_url = form_data.get("MediaUrl0")
    sender = form_data.get("From")

    if not media_url:
        return {"message": "No se recibió ninguna imagen en el mensaje."}

    image_response = requests.get(media_url, auth=(TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN))
    if image_response.status_code == 200:
        image_data = image_response.content

        detected_cars = detect_car_in_image(image_data)
        if not detected_cars:
            send_confirmation_message(sender, "No se detectaron automóviles en la imagen.")
            return {"message": "No se detectaron automóviles en la imagen."}

        damages, highest_confidence_damage, affected_parts, detailed_costs, total_estimated_cost = analyze_car_damage(image_data)
        if damages is None:
            send_confirmation_message(sender, "Error en el análisis de daños con Custom Vision.")
            return {"message": "Error en el análisis de daños con Custom Vision."}

        # Construye el mensaje de respuesta con desglose
        response_message = "Análisis completo.\nAutomóvil detectado: Sí\n"
        response_message += "Partes afectadas y costos estimados:\n"
        for part, details in detailed_costs.items():
            # Verificar si 'damage_type' y otros datos están disponibles en 'details'
            damage_cost = details.get('multiplied_cost', 'N/A')
            severity_message = details.get('severity_message', 'sin información de severidad')
            damage_type = details.get('damage_type', 'desconocido')  # Valor predeterminado si falta 'damage_type'
            
            response_message += (
                f"- {part.capitalize()}: ${damage_cost} "
                f"({severity_message}, daño {damage_type})\n"
            )
        
        response_message += f"Total estimado de reparación: ${total_estimated_cost:.2f} MXN"
        
        send_confirmation_message(sender, response_message)

        return {
            "car_detected": True,
            "detected_cars": detected_cars,
            "damages": damages,
            "highest_confidence_damage": highest_confidence_damage,
            "affected_parts": affected_parts,
            "detailed_costs": detailed_costs,
            "total_estimated_cost": total_estimated_cost
        }
    else:
        raise HTTPException(status_code=500, detail="Error al descargar la imagen.")

def send_confirmation_message(to, body):
    twilio_client.messages.create(
        from_=TWILIO_WHATSAPP_NUMBER,
        body=body,
        to=to
    )
