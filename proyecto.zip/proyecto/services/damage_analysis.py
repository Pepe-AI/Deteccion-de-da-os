# services/damage_analysis.py
import requests
from config import CUSTOM_VISION_API_KEY, CUSTOM_VISION_ENDPOINT, CUSTOM_VISION_PROJECT_ID, CUSTOM_VISION_MODEL_NAME, PARTS_OF_INTEREST

PART_COSTS = {
    "cajuela": 3000,
    "cofre": 5000,
    "faro": 1500,
    "parabrisas": 2000,
    "parachoques delantero": 4000,
    "parachoques trasero": 4000,
    "puerta": 2500,
    "salpicadera": 2000
}

SEVERITY_MULTIPLIERS = {
    "ligero": 1.0,
    "moderado": 1.5,
    "grave": 2.0
}

SEVERITY_MESSAGES = {
    "ligero": "necesita reparación",
    "moderado": "posible reposición",
    "grave": "reposición necesaria"
}

def analyze_car_damage(image_data):
    url = f"{CUSTOM_VISION_ENDPOINT}/{CUSTOM_VISION_PROJECT_ID}/detect/iterations/{CUSTOM_VISION_MODEL_NAME}/image"
    headers = {
        "Prediction-Key": CUSTOM_VISION_API_KEY,
        "Content-Type": "application/octet-stream"
    }
    response = requests.post(url, headers=headers, data=image_data)
    
    if response.status_code == 200:
        predictions = response.json()["predictions"]
        damages_detected = []
        highest_confidence_damage = None
        affected_parts = []

        for prediction in predictions:
            damage_type = prediction["tagName"]
            confidence = prediction["probability"]

            if confidence > 0.8:
                severity = "alto"
            elif 0.6 < confidence <= 0.8:
                severity = "media"
            else:
                continue

            damages_detected.append({
                "damage_type": damage_type,
                "severity": severity,
                "confidence": confidence
            })

            if damage_type in PARTS_OF_INTEREST and damage_type not in affected_parts:
                affected_parts.append(damage_type)

            if damage_type in ["ligero", "moderado", "grave"]:
                if highest_confidence_damage is None or confidence > highest_confidence_damage["confidence"]:
                    highest_confidence_damage = {
                        "damage_type": damage_type,
                        "severity": severity,
                        "confidence": confidence
                    }

        detailed_costs, total_estimated_cost = calculate_repair_estimate(affected_parts, highest_confidence_damage)
        
        return damages_detected, highest_confidence_damage, affected_parts, detailed_costs, total_estimated_cost
    else:
        return None, None, None, None, None

def calculate_repair_estimate(affected_parts, highest_confidence_damage):
    if not affected_parts or not highest_confidence_damage:
        return {}, 0  # Si no hay partes afectadas o daño detectado, no hay costo.

    severity = highest_confidence_damage["damage_type"]
    multiplier = SEVERITY_MULTIPLIERS.get(severity, 1)
    severity_message = SEVERITY_MESSAGES.get(severity, "")

    detailed_costs = {}
    total_cost = 0

    for part in affected_parts:
        part_cost = PART_COSTS.get(part, 0) * multiplier
        detailed_costs[part] = {
            "base_cost": PART_COSTS.get(part, 0),
            "multiplied_cost": part_cost,
            "severity_message": severity_message
        }
        total_cost += part_cost

    return detailed_costs, total_cost
