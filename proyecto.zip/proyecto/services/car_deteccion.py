# services/car_detection.py
from io import BytesIO
from azure.cognitiveservices.vision.computervision.models import VisualFeatureTypes
from vision_client import computervision_client

def detect_car_in_image(image_data):
    image_stream = BytesIO(image_data)
    analysis = computervision_client.analyze_image_in_stream(
        image_stream,
        visual_features=[VisualFeatureTypes.objects]
    )

    detected_cars = [
        {"object": obj.object_property, "confidence": obj.confidence}
        for obj in analysis.objects
        if obj.object_property.lower() in ["car", "vehicle", "station wagon", "land vehicle"]
    ]

    return detected_cars
