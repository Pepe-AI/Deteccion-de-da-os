# vision_client.py
from azure.cognitiveservices.vision.computervision import ComputerVisionClient
from msrest.authentication import CognitiveServicesCredentials
from config import API_KEY, ENDPOINT

# Inicializa el cliente de Computer Vision
computervision_client = ComputerVisionClient(ENDPOINT, CognitiveServicesCredentials(API_KEY))