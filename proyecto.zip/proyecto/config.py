# config.py

API_KEY = "FKorAoxFqrCl6sOiuBZqjO37lwftjxicGiN77scQ0rMeXjTIiLO0JQQJ99AKACYeBjFXJ3w3AAAFACOGUMId"
ENDPOINT = "https://proyectotrabajo.cognitiveservices.azure.com/"

CUSTOM_VISION_API_KEY = "1xN2e0eXkOSpE1t4YIDoghKSYCBsoOTrVOnFn7PBzZeliYfZlkqcJQQJ99AKACYeBjFXJ3w3AAAIACOG8mqE"
CUSTOM_VISION_ENDPOINT = "https://proyectotrabajocustom-prediction.cognitiveservices.azure.com/customvision/v3.0/Prediction"
CUSTOM_VISION_PROJECT_ID = "10ca8f47-b612-4ddb-b86d-48d6b915a7db"
CUSTOM_VISION_MODEL_NAME = "damage_detected"

PARTS_OF_INTEREST = [
    "cajuela", "cofre", "faro", "parabrisas", "parachoques delantero",
    "parachoques trasero", "puerta", "salpicadera"
]   

# Twilio
TWILIO_ACCOUNT_SID = "ACa907a47c5deceb262b9d7fcecd0e3cf4"
TWILIO_AUTH_TOKEN = "a825a230267eae1d65335665764339d6"
TWILIO_WHATSAPP_NUMBER = "whatsapp:+14155238886"